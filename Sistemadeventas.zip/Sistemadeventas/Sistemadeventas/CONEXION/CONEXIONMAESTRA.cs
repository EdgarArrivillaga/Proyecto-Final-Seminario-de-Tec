﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistemadeventas.CONEXION
{
    class CONEXIONMAESTRA
    {
        public static string conexion = "DATA SOURCE=LAPTOP-6APJK8AE; initial catalog=BDProyecto; Integrated Security=True";
    }
}
